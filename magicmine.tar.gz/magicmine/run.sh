#!/usr/bin/env bash
cd "$(dirname "$0")/miner"
echo "[MAGICMINE] Starting custom miner..."
exec python3 mine.py
