#!/bin/bash  

# Название сессии screen  
SESSION_NAME="miner"  

# Путь к майнеру  
MINER_DIR="/gpu-miner"  
MINER_SCRIPT="mine.py"  

# Файл для временного хранения логов  
LOG_FILE="/gpu-miner/miner_temp.log"  

# Запускаем майнер с перенаправлением логов  
start_miner() {  
    echo "Starting miner at $(date)"  
    cd $MINER_DIR  
    screen -dmS $SESSION_NAME bash -c "python3 $MINER_SCRIPT > $LOG_FILE 2>&1; exec bash"  
}  

# Проверяем, обновляются ли логи  
check_logs() {  
    if [ -f "$LOG_FILE" ]; then  
        # Получаем время последнего изменения файла  
        LAST_MODIFIED=$(stat -c %Y "$LOG_FILE" 2>/dev/null || echo 0)  
        CURRENT_TIME=$(date +%s)  
        # Если логи не обновлялись более 5 минут (300 секунд), считаем, что майнер завис  
        if [ $((CURRENT_TIME - LAST_MODIFIED)) -gt 300 ]; then  
            return 1  
        fi  
    fi  
    return 0  
}  

while true; do  
    # Проверяем, существует ли сессия screen  
    if screen -list | grep -q "$SESSION_NAME"; then  
        # Проверяем, работает ли процесс python3  
        if ! pgrep -f "python3 $MINER_SCRIPT" > /dev/null; then  
            echo "Miner process not running, restarting..."  
            screen -X -S $SESSION_NAME quit  
            sleep 2  
            start_miner  
        elif ! check_logs; then  
            echo "Miner logs not updating, restarting..."  
            screen -X -S $SESSION_NAME quit  
            sleep 2  
            start_miner  
        else  
            echo "Miner running at $(date)"  
        fi  
    else  
        echo "No miner session found, starting..."  
        start_miner  
    fi  
    sleep 60  # Проверяем каждые 60 секунд  
done  
