#!/bin/bash
SESSION="miner" 
SCRIPT="/gpu-miner/mine.py" 
PYTHON="/usr/bin/python3"

# Если сессии нет — запустить
if ! screen -list | grep -q "\.${SESSION}"; then
    echo "$(date): miner not running, restarting..." >> /gpu-miner/watchdog.log
    screen -dmS $SESSION $PYTHON $SCRIPT 
else
    echo "$(date): miner is running" >> /gpu-miner/watchdog.log
fi
