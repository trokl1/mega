#!/bin/bash
SESSION="miner"
SCRIPT="/gpu-miner/mine.py"
PYTHON="/usr/bin/python3"

# Удалим старую сессию, если осталась
screen -S $SESSION -X quit

# Запускаем новую screen-сессию
screen -dmS $SESSION $PYTHON $SCRIPT
