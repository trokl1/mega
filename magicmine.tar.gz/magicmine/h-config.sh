#!/usr/bin/env bash
CUSTOM_CONFIG_FILENAME="miner.conf"
